# Stage 8 upload / build

Repository: https://github.com/Gregorilass/Empty

**Status:** This source archive is prepared for GitHub upload, but Stage 8 has NOT been committed to the repository or compiled. The connected GitHub integration refused permission to create a test branch. The archive's offline Stage 7 and Stage 8 regression checks pass.

## Upload using the existing workflow

1. In the repository, select **Add file -> Upload files**.
2. Upload the file named exactly **`AncientWarfare_Stages_5_and_6_GitHub_Upload.zip`** from this release to the `main` branch and commit the upload. The historical filename is required by the existing `.github/workflows/import.yml` trigger, even though the archive **contains Stage 8**.
3. Existing GitHub Actions will extract the complete source, verify previous stages and build with Java 25 / Gradle 9.2.1. The archive also installs `.github/workflows/stage8.yml`, which runs the Stage 8 checks on subsequent source commits to `main`.
4. If the build succeeds, download the resulting GitHub Actions artifact and inspect the inner JAR. Expected filename: **`ancientwarfare-0.0.8-stage8.jar`**. If it fails, inspect the first Java compiler error in the Actions log and correct it before any gameplay testing.
5. **Back up the world.** Test the compiled JAR on a copied Minecraft 26.3 / NeoForge 26.3.0.101 server and matching client. Replace the previous Ancient Warfare JAR on both sides; do not run two Ancient Warfare JARs concurrently.

Local checks (where Java 25 and Gradle 9.2.1 are installed):

```
python3 scripts/validate_stage8.py
gradle --no-daemon --stacktrace build
```

A green build is not a guarantee of successful in-game behavior. See `reports/STAGE8_LIMITATIONS.md` for the in-game regression procedure.
